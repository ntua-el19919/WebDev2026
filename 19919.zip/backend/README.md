
Web Applications Development 2026 - MovieLens Project 
Αυτή η εφαρμογή υλοποιεί ένα πλήρες σύστημα προτάσεων ταινιών βασισμένο στο MovieLens Latest Small dataset. 
Αποτελείται από ένα backend γραμμένο σε Python (FastAPI) και ένα frontend σε Vanilla HTML, CSS και JavaScript.

## Προαπαιτούμενα
- Εγκατεστημένη Python 3.8 ή νεότερη.
- Τα αρχεία του dataset (`movies.csv`, `ratings.csv`, `tags.csv`) πρέπει να βρίσκονται στον φάκελο `backend`.

## Οδηγίες Εγκατάστασης και Εκτέλεσης 

### 1. Στήσιμο και Εκκίνηση του Backend
Ανοίξτε ένα τερματικό και πλοηγηθείτε στον φάκελο `backend`:
```bash
cd backend

```

**Βήμα 1.1: Εγκατάσταση Εξαρτήσεων**
Εγκαταστήστε τις απαιτούμενες βιβλιοθήκες μέσω του manifest αρχείου `requirements.txt`:

```bash
pip install -r requirements.txt

```

**Βήμα 1.2: Δημιουργία Βάσης Δεδομένων**
Εκτελέστε το script αρχικοποίησης για να δημιουργηθεί η SQLite βάση δεδομένων και να φορτωθούν τα αρχικά δεδομένα από τα CSV. Το script δημιουργεί επίσης τα απαραίτητα indexes (στους πίνακες movieId και userId) για τη βελτιστοποίηση των queries:

```bash
python dbPopulate.py

```

**Βήμα 1.3: Εκκίνηση του Server**
Ξεκινήστε τον FastAPI server χρησιμοποιώντας το Uvicorn. Ο server ρυθμίζεται να ακούει στη θύρα 3000, όπως ορίζουν οι προδιαγραφές του API:

```bash
uvicorn main:app --reload --port 3000

```

Το API θα είναι πλέον διαθέσιμο στο base URL: `http://localhost:3000/movielens/api`.
*Σημείωση:* Μπορείτε να δείτε το διαδραστικό documentation των RESTful APIs (Swagger UI) στη διεύθυνση: `http://localhost:3000/docs`.

### 2. Εκκίνηση του Frontend

Το frontend δεν χρησιμοποιεί εξωτερικές βιβλιοθήκες ή frameworks.

Ανοίξτε ένα νέο τερματικό, πλοηγηθείτε στον φάκελο `frontend` και τρέξτε έναν απλό HTTP server της Python για να σερβίρετε τα αρχεία:

```bash
cd frontend
python3 -m http.server 8000

```

Στη συνέχεια, ανοίξτε τον browser σας και επισκεφθείτε τη διεύθυνση: `http://localhost:8000`.


(Εναλλακτικά, μπορείτε απλά να ανοίξετε το αρχείο `index.html`  απευθείας στον browser σας με διπλό κλικ).

## Βασική Λειτουργικότητα

* 
**Προσθήκη Ταινίας:** Προσθήκη νέων ταινιών στη βάση δεδομένων μέσω φόρμας με success/failure feedback.


* 
**Αναζήτηση:** Case-insensitive αναζήτηση ταινιών με βάση λέξη-κλειδί στον τίτλο.


* **Βαθμολόγηση & Μέσος Όρος:** Δυνατότητα βαθμολόγησης ταινιών και προβολή της μέσης βαθμολογίας. Οι βαθμολογίες του session διατηρούνται προσωρινά στη μνήμη του browser.


* 
**Συστάσεις (Recommendations):** Εξαγωγή προσωποποιημένων προτάσεων ταινιών. Ο υπολογισμός γίνεται με τον αλγόριθμο User-Based Collaborative Filtering (συσχέτιση Pearson σε co-rated items) , επιλέγοντας τους top-K πιο όμοιους χρήστες.






